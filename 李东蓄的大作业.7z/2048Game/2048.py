import random
import time
import os

from pykeyboard import PyKeyboard  # 键盘实例
from selenium import webdriver  # web驱动
from selenium.webdriver import ActionChains  # 鼠标模拟
from selenium.webdriver.common.by import By

# 通过相对路径来得到 绝对路径=os.path.abspath(相对路径)
path = r'../2048Game/index.html'
file_open = open(path, mode='r')
# print(os.path.abspath(path))

url = os.path.abspath(path)

# 获取webdriver驱动，这里用的是谷歌
driver = webdriver.Chrome()
# 用浏览器打开
driver.get(url)
# 设置隐式等待时间为3秒
driver.implicitly_wait(3)

# 定义一些变量
now_number = []  # 存储现在的界面数字数组，在以后的算法之中可能会用到，当前可不写
k = PyKeyboard()  # 键盘对象


# 获取当前页面的状态数组，返回的是一个一维列表
def get_now_numbers(driver):
    global now_number  # 声明使用的是全局变量
    now_number.clear()  # 对列表进行清空，防止有脏数据
    for i in range(4):
        for j in range(4):
            # 用CSS选择器查找每一个小方格里面的数字，并且添加到数组中
            cell_span = driver.find_element(By.CSS_SELECTOR, '#number-cell-{}-{}'.format(i, j))
            num = cell_span.text
            if num == "":
                now_number.append(0)
            else:
                now_number.append(int(num))


# 开始新游戏
def new_game(driver):
    # 查找开始游戏按钮
    new_game_button = driver.find_element(By.CSS_SELECTOR, '#new_game_button')
    time.sleep(2)
    # 实例化鼠标方法
    actions = ActionChains(driver)
    # 开始一个新游戏
    actions.click(new_game_button)
    # 调用点击方法
    actions.perform()


# 随机按键按键效果
def press_key_r(num):
    if num == 0:
        # 按左移键
        k.tap_key(k.left_key)
    elif num == 1:
        # 按右移键
        k.tap_key(k.right_key)
    elif num == 2:
        # 按上移键
        k.tap_key(k.up_key)
    else:
        # 按下移键
        k.tap_key(k.down_key)


# 开始新游戏
new_game(driver=driver)
# 获取初始游戏界面
get_now_numbers(driver=driver)
time.sleep(2)

flag = 0
# 定义一个死循环一直按键
while flag == 0:
    # 是否弹出gameover警告框
    # 因为alert是在js里面定义的，所以可以直接用driver.switch_to.alert获取
    try:
        alert = driver.switch_to.alert
        print(alert.text)
        # 游戏结束
        if alert.text == "gameover!":
            alert.accept()
            flag = 1
            break

    except Exception:
        # 产生一个随机数，随机上下左右移
        num = random.randint(0, 3)
        press_key_r(num)
        # print("继续操作...")
        time.sleep(0.2)

# 获取分数
score = driver.find_element(By.ID, "score").text
print("本次得分为：{}".format(score))

