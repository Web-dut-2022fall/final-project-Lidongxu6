// 游戏数据
var board = new Array();
// 游戏分数
var score = 0;
var hasConflicted = new Array();

var startx = 0;
var starty = 0;
var endx = 0;
var endy = 0;


// 当整个程序运行完毕之后加载的主函数
$(document).ready(function () {
    prepareForMobile(); //准备工作
    newgame(); //开始一个新游戏
});

function prepareForMobile() {

    //如果屏幕特别大，界面也写死
    if (documentWidth > 500) {
        gridContainerWidth = 500;
        cellSideLength = 100;
        cellSpace = 20;
    }

    $("#grid-container").css("width", gridContainerWidth - 2 * cellSpace);
    $("#grid-container").css("height", gridContainerWidth - 2 * cellSpace);
    $("#grid-container").css("padding", cellSpace);
    $("#grid-container").css("border-radius", gridContainerWidth * 0.02);

    $(".grid-cell").css("width", cellSideLength);
    $(".grid-cell").css("height", cellSideLength);
    $(".grid-cell").css("border-radius", cellSideLength * 0.02);

}

function newgame() {
    //初始化棋盘格
    Init();
    //随机在两个棋盘格生成数字（2或者4）
    generateOneNumber();
    generateOneNumber();

}

function Init() {

    score = 0;
    for (var i = 0; i < 4; i++) {
        for (var j = 0; j < 4; j++) {

            var gridCell = $("#grid-cell-" + i + "-" + j);
            // 距离顶端的距离
            gridCell.css('top', getPostTop(i, j));
            // 距离左端距离
            gridCell.css('left', getPostLeft(i, j));

        }
    }

    //将board变为一个二维数组
    for (var i = 0; i < 4; i++) {
        board[i] = new Array();
        hasConflicted[i] = new Array();
        for (var j = 0; j < 4; j++) {
            board[i][j] = 0;
            hasConflicted[i][j] = false;
        }
    }
    
    updateBoardView();
}

//根据board的值对页面的元素进行操作
function updateBoardView() {

    $(".number-cell").remove();
    for (var i = 0; i < 4; i++) {
        for (var j = 0; j < 4; j++) {

            //动态的给每一个格加上数字显示标签
            $("#grid-container").append('<div class="number-cell" id="number-cell-' + i + '-' + j + '"></div>')
            var theNumberCell = $('#number-cell-' + i + '-' + j);

            if (board[i][j] == 0) {
                //为0时不显示
                theNumberCell.css('width', '0px');
                theNumberCell.css('height', '0px');
                //中心显示，长度的一半
                theNumberCell.css('top', getPostTop(i, j) + cellSideLength * 0.5);
                theNumberCell.css('left', getPostLeft(i, j) + cellSideLength * 0.5);

            } else {

                theNumberCell.css('width', cellSideLength);
                theNumberCell.css('height', cellSideLength);
                theNumberCell.css('top', getPostTop(i, j));
                theNumberCell.css('left', getPostLeft(i, j));
                theNumberCell.css('background-color', getNumberBackgroundColor(board[i][j]));
                theNumberCell.css('color', getNumberColor(board[i][j]));
                theNumberCell.text(board[i][j]);

            }
            hasConflicted[i][j] = false;
        }
    }
    $(".number-cell").css("line-height", cellSideLength + "px");
    $(".number-cell").css("font-size", 0.6 * cellSideLength + "px");
}

function generateOneNumber() {

    //判断当前棋盘是否还有空闲格子
    if (nospace(board)) {
        return false;
    }

    // 随机一个位置
    var randx;
    var randy;
    while (true) {
        randx = parseInt(Math.floor(Math.random() * 4));
        randy = parseInt(Math.floor(Math.random() * 4));
        if (board[randx][randy] == 0) break;
    }

    // 随机一个数字
    var randNumber = Math.random() < 0.5 ? 2 : 4;

    //显示
    board[randx][randy] = randNumber;
    showNumberWithAnimation(randx, randy, randNumber);

    return true;
}


//当玩家按下一个按钮
$(document).keydown(function (event) {

    switch (event.keyCode) {
        case 37: //left
            event.preventDefault();
            //判断是否可以向左移动
            if (moveLeft()) {
                //向左移动之后生成一个新的数字
                setTimeout("generateOneNumber()", 310);
                //判断是否游戏结束
                setTimeout("isgameover()", 360);
            }
            break;

        case 38: //up
            event.preventDefault();
            //判断是否可以向上移动
            if (moveUp()) {
                //向上移动之后生成一个新的数字
                setTimeout("generateOneNumber()", 310);
                //判断是否游戏结束
                setTimeout("isgameover()", 360);
            }
            break;

        case 39: //right
            event.preventDefault();
            //判断是否可以向右移动
            if (moveRight()) {
                //向右移动之后生成一个新的数字
                setTimeout("generateOneNumber()", 310);
                //判断是否游戏结束
                setTimeout("isgameover()", 360);
            }
            break;

        case 40: //down
            event.preventDefault();
            //判断是否可以向下移动
            if (moveDown()) {
                //向下移动之后生成一个新的数字
                setTimeout("generateOneNumber()", 310);
                //判断是否游戏结束
                setTimeout("isgameover()", 360);
            }
            break;

        default:
            break;
    }

});

//监听按钮点击开始
document.addEventListener('touchstart', function (event) {
    startx = event.touches[0].pageX;
    starty = event.touches[0].pageY;
})

document.addEventListener("touchmove",function(event){
    event.preventDefault();
})

//监听按钮点击结束
document.addEventListener('touchend', function (event) {
    endx = event.changedTouches[0].pageX;
    endy = event.changedTouches[0].pageY;

    //改变量
    var deltax = endx - startx;
    var deltay = endy - starty;

    //判断是否为点击事件而不是滑动
    if (Math.abs(deltax) < 0.15 * documentWidth && Math.abs(deltay) < 0.15 * documentWidth) {
        return;
    }
    

    if (Math.abs(deltax) >= Math.abs(deltay)) {//x方向

        if (deltax > 0) {//向右滑动
            if (moveRight()) {
                //向右移动之后生成一个新的数字
                setTimeout("generateOneNumber()", 310);
                //判断是否游戏结束
                setTimeout("isgameover()", 360);
            }
        } else {//向左滑动
            if (moveLeft()) {
                //向左移动之后生成一个新的数字
                setTimeout("generateOneNumber()", 310);
                //判断是否游戏结束
                setTimeout("isgameover()", 360);
            }

        }

    } else {//y方向
        if (deltay > 0) {//向下
            if (moveDown()) {
                //向下移动之后生成一个新的数字
                setTimeout("generateOneNumber()", 310);
                //判断是否游戏结束
                setTimeout("isgameover()", 360);
            }
        } else {//向上
            if (moveUp()) {
                //向上移动之后生成一个新的数字
                setTimeout("generateOneNumber()", 310);
                //判断是否游戏结束
                setTimeout("isgameover()", 360);
            }
        }
    }

})

//游戏结束
function isgameover() {
    if (nospace(board) && nomove(board)) {
        gameover();
    }
}

function gameover() {
    alert('gameover!');
}

function moveLeft() {

    //是否可以向左移动
    if (!canMoveLeft(board)) {
        return false;
    }

    for (var i = 0; i < 4; i++) {
        for (var j = 1; j < 4; j++) {
            if (board[i][j] != 0) {
                for (var k = 0; k < j; k++) {
                    if (board[i][k] == 0 && noBlockHorizontal(i, k, j, board) && !hasConflicted[i][k]) {
                        //move
                        showMoveAnimation(i, j, i, k);
                        board[i][k] = board[i][j];
                        board[i][j] = 0;
                        continue;
                    } else if (board[i][k] == board[i][j] && noBlockHorizontal(i, k, j, board)) {
                        //move
                        showMoveAnimation(i, j, i, k);
                        //add
                        board[i][k] = board[i][j] + board[i][k];
                        board[i][j] = 0;
                        //add Score
                        score += board[i][k];
                        updateScore(score);
                        hasConflicted[i][k] = true;
                        continue;
                    }
                }
            }
        }
    }

    //隔300ms执行
    setTimeout("updateBoardView()", 300);
    return true;
}

function moveUp() {

    //是否可以向上移动
    if (!canMoveUp(board)) {
        return false;
    }

    for (var j = 0; j < 4; j++) {
        for (var i = 1; i < 4; i++) {
            if (board[i][j] != 0) {
                for (var k = 0; k < i; k++) {
                    if (board[k][j] == 0 && noBlockVertical(j, k, i, board)) {
                        //move
                        showMoveAnimation(i, j, k, j);
                        board[k][j] = board[i][j];
                        board[i][j] = 0;
                        continue;
                    } else if (board[k][j] == board[i][j] && noBlockVertical(j, k, i, board) && !hasConflicted[k][j]) {
                        //move
                        showMoveAnimation(i, j, k, j);
                        //add
                        board[k][j] += board[i][j];
                        board[i][j] = 0;
                        score += board[k][j];
                        updateScore(score);
                        hasConflicted[k][j] = true;
                        continue;
                    }
                }
            }
        }
    }

    //隔300ms执行
    setTimeout("updateBoardView()", 300);
    return true;
}

function moveRight() {

    //是否可以向右移动
    if (!canMoveRight(board)) {
        return false;
    }

    for (var i = 0; i < 4; i++) {
        for (var j = 2; j >= 0; j--) {
            if (board[i][j] != 0) {
                for (var k = 3; k > j; k--) {
                    if (board[i][k] == 0 && noBlockHorizontal(i, j, k, board)) {
                        //move
                        showMoveAnimation(i, j, i, k);
                        board[i][k] = board[i][j];
                        board[i][j] = 0;
                        continue;
                    } else if (board[i][k] == board[i][j] && noBlockHorizontal(i, j, k, board) && !hasConflicted[i][k]) {
                        //move
                        showMoveAnimation(i, j, i, k);
                        //add
                        board[i][k] = board[i][j] + board[i][k];
                        board[i][j] = 0;
                        //addscore
                        score += board[i][k];
                        updateScore(score);
                        hasConflicted[i][k] = true;
                        continue;
                    }
                }
            }
        }
    }

    //隔300ms执行
    setTimeout("updateBoardView()", 300);
    return true;
}


function moveDown() {

    //是否可以向下移动
    if (!canMoveDown(board)) {
        return false;
    }

    for (var j = 0; j < 4; j++) {
        for (var i = 2; i >= 0; i--) {
            if (board[i][j] != 0) {
                for (var k = 3; k > i; k--) {
                    if (board[k][j] == 0 && noBlockVertical(j, i, k, board)) {
                        //move
                        showMoveAnimation(i, j, k, j);
                        board[k][j] = board[i][j];
                        board[i][j] = 0;
                        continue;
                    } else if (board[k][j] == board[i][j] && noBlockVertical(j, i, k, board) && !hasConflicted[k][j]) {
                        //move
                        showMoveAnimation(i, j, k, j);
                        //add
                        board[k][j] += board[i][j];
                        board[i][j] = 0;
                        score += board[k][j];
                        updateScore(score);
                        hasConflicted[k][j] = true;
                        continue;
                    }
                }
            }
        }
    }

    //隔300ms执行
    setTimeout("updateBoardView()", 300);
    return true;
}


